The shapefiles present in the folder 'Shape_File' is used in the study.

'qgis2web_files' folder contains the web map files to be uploaded in the server.

'Uttarakhand_road' folder contains the road data obtained form PMGSY portal.

